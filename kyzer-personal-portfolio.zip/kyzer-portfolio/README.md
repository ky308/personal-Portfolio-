# Personal Portfolio Website

## Folder structure
- `index.html` — main website
- `styles/style.css` — all design and responsive styling
- `assets/profile-placeholder.svg` — optional placeholder graphic

## Run locally
Open `index.html` in a web browser. No framework or installation is required.

## Before submitting
1. Replace the sample email `your.email@example.com` in `index.html` with your real email.
2. Update any personal details, skills, education, or wording so everything is accurate.
3. If you want to use a real profile photo, put it in `assets/` and replace the initials avatar in the HTML with an `<img>` element.
4. Test the page on both phone and computer.

## Publish with GitHub Pages
1. Create a GitHub repository named `lastname-project-1` (replace `lastname` with your surname).
2. Upload the contents of this folder to the repository's root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site. Your URL will look like `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Suggested commit history (make each commit after a real change)
1. Add initial project structure
2. Create portfolio HTML skeleton
3. Add navigation menu
4. Build hero section
5. Add about section
6. Add skills section
7. Add education section
8. Add contact section
9. Add responsive CSS styles
10. Polish content and fix layout
